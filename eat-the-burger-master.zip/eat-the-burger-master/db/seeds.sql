INSERT INTO burgers (burger_name, devoured)
VALUES('The Zicatela Burger', true);
INSERT INTO burgers (burger_name, devoured)
VALUES('The Carrizalillo  Burger', true);
INSERT INTO burgers (burger_name, devoured)
VALUES('The La Punta Burger', false);
INSERT INTO burgers (burger_name, devoured)
VALUES('The Puerto Burger', false);
INSERT INTO burgers (burger_name, devoured)
VALUES('The Spot Classic Burger', true);
INSERT INTO burgers (burger_name, devoured)
VALUES('The Adoquin Burger', false);